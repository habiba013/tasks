const express = require("express");
const Pet = require("../models/Pet");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const pet = await Pet.create(req.body);

    res.status(201).json({
      message: "Pet created successfully",
      pet
    });
  } catch (error) {
    res.status(500).json({
      message: "Error creating pet",
      error: error.message
    });
  }
});

router.get("/", async (req, res) => {
  try {
    const pets = await Pet.find();

    res.status(200).json({
      message: "Pets fetched successfully",
      pets
    });
  } catch (error) {
    res.status(500).json({
      message: "Error fetching pets",
      error: error.message
    });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const pet = await Pet.findById(req.params.id);

    if (!pet) {
      return res.status(404).json({
        message: "Pet not found"
      });
    }

    res.status(200).json({
      message: "Pet fetched successfully",
      pet
    });
  } catch (error) {
    res.status(500).json({
      message: "Error fetching pet",
      error: error.message
    });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const pet = await Pet.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!pet) {
      return res.status(404).json({
        message: "Pet not found"
      });
    }

    res.status(200).json({
      message: "Pet updated successfully",
      pet
    });
  } catch (error) {
    res.status(500).json({
      message: "Error updating pet",
      error: error.message
    });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const pet = await Pet.findByIdAndDelete(req.params.id);

    if (!pet) {
      return res.status(404).json({
        message: "Pet not found"
      });
    }

    res.status(200).json({
      message: "Pet deleted successfully",
      pet
    });
  } catch (error) {
    res.status(500).json({
      message: "Error deleting pet",
      error: error.message
    });
  }
});

module.exports = router;